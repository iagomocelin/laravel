<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('paramaiusculo/{palavra}','StringsController@paraMaiusculo');

Route::get('paramaiusculoformatada/{palavra}','StringsController@paraMaiusculoFormatada');

Route::get('reverter/{palavra}','StringsController@reverso');

Route::get('capital/{palavra}','StringsController@capital');

Route::get('sort/{palavra}','StringsController@sort');

Route::get('aleatorio/{palavra}','StringsController@aleatorio');

Route::get('paracaractere/{palavra}','StringsController@paraArray');

Route::get('olamundo', function(){
	return "Olá, mundo!";
});

Route::get('olapessoa/{nome?}', function($nome='Fulano'){
	return "Olá, " . ucfirst($nome);
});