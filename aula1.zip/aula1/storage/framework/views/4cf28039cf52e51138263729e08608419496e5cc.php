<html>
<body>

	<h1>Caracteres enviados por parâmetro: <?php echo e($original); ?><h1>
	<hr>

	<?php $__currentLoopData = $vetor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elemento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<p><?php echo e($elemento); ?></p>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>