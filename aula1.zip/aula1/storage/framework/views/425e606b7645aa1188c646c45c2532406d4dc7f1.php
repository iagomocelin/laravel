<html>
<body>
	<h1><?php echo e($original); ?></h1>
	<hr>
	<h2><?php echo e($modificada); ?></h2>
</body>
</html>