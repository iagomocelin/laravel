<html>
<body>
	<h1>{{$original}}</h1>
	<hr>
	<h2>{{$modificada}}</h2>
</body>
</html>